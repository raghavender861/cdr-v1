"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Header from "./components/Header"
import Sidebar from "./components/Sidebar"
import AnalystSelection from "./components/AnalystSelection"
import ChatInterface from "./components/ChatInterface"
import RightSidebar from "./components/RightSidebar"
import { useAppContext } from "./context/AppContext"

export default function Home() {
  const { currentConversationId, selectedAnalyst, isSidebarOpen, isRightSidebarOpen } = useAppContext()
  const [isMobile, setIsMobile] = useState(false)

  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768)
    }
    handleResize()
    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  return (
    <div className="flex h-screen overflow-hidden bg-gradient-to-br from-purple-50 to-blue-100">
      <AnimatePresence>
        {(isSidebarOpen || !isMobile) && (
          <motion.div
            initial={{ x: -300 }}
            animate={{ x: 0 }}
            exit={{ x: -300 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className={`${isMobile ? "absolute" : "relative"} z-20 h-full`}
          >
            <Sidebar />
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex flex-col flex-grow overflow-hidden">
        <Header />
        <main className="flex-grow overflow-auto mt-16">
          {!currentConversationId && !selectedAnalyst ? <AnalystSelection /> : <ChatInterface />}
        </main>
      </div>

      <AnimatePresence>
        {isRightSidebarOpen && selectedAnalyst && (
          <motion.div
            initial={{ x: 300 }}
            animate={{ x: 0 }}
            exit={{ x: 300 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="relative z-20 h-full"
          >
            <RightSidebar />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}

