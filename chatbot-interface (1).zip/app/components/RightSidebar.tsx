"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { useAppContext } from "../context/AppContext"
import { FaTable } from "react-icons/fa"

const tableData = {
  "Vulnerability Analyst": ["OnPrem", "AppSec", "Cloud Vulnerabilities"],
  "Cloud Security Analyst": ["Cloud Service Compliance", "Cloud Security Controls", "Untagged Issues"],
  "SSDF Agent": ["SSDF Forms", "SSDF Tasks", "SSDF Controls"],
}

const RightSidebar = () => {
  const { selectedAnalyst } = useAppContext()
  const [selectedTable, setSelectedTable] = useState("")
  const [isCollapsed, setIsCollapsed] = useState(true)
  const [columnSchema, setColumnSchema] = useState<{ name: string; explanation: string }[]>([])

  const handleTableClick = (table: string) => {
    if (selectedTable === table) {
      setSelectedTable("")
      setColumnSchema([])
    } else {
      setSelectedTable(table)
      setColumnSchema([
        { name: "ID", explanation: "Unique identifier for the record" },
        { name: "Name", explanation: "Name of the vulnerability or issue" },
        { name: "Severity", explanation: "Severity level of the vulnerability or issue" },
        { name: "Description", explanation: "Detailed description of the vulnerability or issue" },
      ])
    }
  }

  return (
    <motion.div
      initial={{ x: 300 }}
      animate={{ x: 0 }}
      exit={{ x: 300 }}
      className={`bg-gray-100 h-full ${isCollapsed ? "w-16" : "w-64"} transition-all duration-300 ease-in-out overflow-hidden`}
    >
      <div className="p-4">
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="mb-4 text-2xl hover:text-gray-600 transition-colors duration-200"
        >
          {isCollapsed ? "←" : "→"}
        </button>
        <h2 className={`text-xl font-bold mb-4 ${isCollapsed ? "hidden" : ""}`}>Column Schema</h2>
        <div className="mb-4">
          {tableData[selectedAnalyst as keyof typeof tableData]?.map((table) => (
            <button
              key={table}
              onClick={() => handleTableClick(table)}
              className={`flex items-center justify-center w-full text-left p-2 rounded mb-2 ${
                selectedTable === table ? "bg-blue-500 text-white" : "bg-white hover:bg-gray-200"
              }`}
            >
              {isCollapsed ? <FaTable className="text-xl" /> : <span>{table}</span>}
            </button>
          ))}
        </div>
      </div>
      {selectedTable && !isCollapsed && (
        <div className="px-4">
          <h3 className="font-bold mb-2">{selectedTable} Schema</h3>
          <table className="w-full">
            <thead>
              <tr>
                <th className="w-1/3 text-left">Column</th>
                <th className="w-2/3 text-left">Explanation</th>
              </tr>
            </thead>
            <tbody>
              {columnSchema.map((column) => (
                <tr key={column.name}>
                  <td className="border-t py-2">{column.name}</td>
                  <td className="border-t py-2">
                    <div className="break-words">{column.explanation}</div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </motion.div>
  )
}

export default RightSidebar

