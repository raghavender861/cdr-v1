"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { FaUser, FaRobot, FaBug, FaCloud, FaCode } from "react-icons/fa"
import { useAppContext } from "../context/AppContext"
import ExampleQuestionsModal from "./ExampleQuestionsModal"

const analystIcons = {
  "Vulnerability Analyst": FaBug,
  "Cloud Security Analyst": FaCloud,
  "SSDF Agent": FaCode,
}

const ChatInterface = () => {
  const { currentConversationId, selectedAnalyst } = useAppContext()
  const [messages, setMessages] = useState<{ role: string; content: string }[]>([])
  const [input, setInput] = useState("")
  const [isModalOpen, setIsModalOpen] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim()) return

    const newMessage = { role: "user", content: input }
    setMessages([...messages, newMessage])

    // Simulating API call
    const payload = {
      user_id: "raghu-react",
      conversation_id: currentConversationId,
      user_input: input,
      Analyst: selectedAnalyst,
    }
    console.log("API Payload:", payload)

    setInput("")
  }

  const AnalystIcon = selectedAnalyst ? analystIcons[selectedAnalyst as keyof typeof analystIcons] : FaRobot

  return (
    <div className="flex flex-col h-full mt-16">
      {selectedAnalyst && (
        <div className="bg-gray-800 text-white p-4 flex items-center">
          <AnalystIcon className="text-2xl mr-2" />
          <span className="font-bold">{selectedAnalyst}</span>
        </div>
      )}
      <div className="flex-grow overflow-auto p-4">
        {messages.map((message, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className={`flex ${message.role === "user" ? "justify-end" : "justify-start"} mb-4`}
          >
            <div className={`flex items-start ${message.role === "user" ? "flex-row-reverse" : ""}`}>
              <div className={`rounded-full p-2 ${message.role === "user" ? "bg-blue-500" : "bg-gray-300"}`}>
                {message.role === "user" ? <FaUser className="text-white" /> : <AnalystIcon />}
              </div>
              <div
                className={`max-w-xs mx-2 p-3 rounded-lg ${message.role === "user" ? "bg-blue-100" : "bg-gray-200"}`}
              >
                {message.content}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
      <form onSubmit={handleSubmit} className="p-4 bg-gray-100">
        <div className="flex flex-col">
          <div className="flex mb-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className="flex-grow p-2 border rounded-l-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Type your message..."
            />
            <button
              type="submit"
              className="bg-blue-500 text-white p-2 rounded-r-lg hover:bg-blue-600 transition-colors duration-200"
            >
              Send
            </button>
          </div>
          <button
            type="button"
            onClick={() => setIsModalOpen(true)}
            className="bg-gray-300 text-gray-700 p-2 rounded-lg hover:bg-gray-400 transition-colors duration-200"
          >
            Example Questions
          </button>
        </div>
      </form>
      <ExampleQuestionsModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} setInput={setInput} />
    </div>
  )
}

export default ChatInterface

