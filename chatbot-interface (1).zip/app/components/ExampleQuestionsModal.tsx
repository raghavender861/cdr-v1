"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { useAppContext } from "../context/AppContext"
import type React from "react" // Added import for React

const exampleQuestions = {
  "Vulnerability Analyst": {
    OnPrem: [
      "What are common on-premises vulnerabilities?",
      "How to secure a local network?",
      "Best practices for patch management in on-premises environments",
    ],
    AppSec: [
      "What are OWASP Top 10 vulnerabilities?",
      "How to implement secure authentication in web applications?",
      "Best practices for input validation and sanitization",
    ],
    "Cloud Vulnerabilities": [
      "Common misconfigurations in cloud environments",
      "How to secure data in transit and at rest in the cloud",
      "Best practices for identity and access management in cloud services",
    ],
  },
  "Cloud Security Analyst": {
    "Cloud Service Compliance": [
      "How to ensure GDPR compliance in cloud environments?",
      "What are the key compliance requirements for healthcare data in the cloud?",
      "Best practices for maintaining PCI DSS compliance in cloud services",
    ],
    "Cloud Security Controls": [
      "What are the essential security controls for AWS environments?",
      "How to implement least privilege access in Azure?",
      "Best practices for network segmentation in Google Cloud Platform",
    ],
    "Untagged Issues": [
      "How to identify and manage shadow IT in cloud environments?",
      "Best practices for handling unmanaged cloud resources",
      "Strategies for discovering and securing rogue cloud instances",
    ],
  },
  "SSDF Agent": {
    "SSDF Forms": [
      "What are the key components of an SSDF form?",
      "How to properly document secure development practices using SSDF forms?",
      "Best practices for integrating SSDF forms into the development lifecycle",
    ],
    "SSDF Tasks": [
      "What are common SSDF tasks for secure software development?",
      "How to prioritize SSDF tasks in an agile development environment?",
      "Best practices for automating SSDF tasks in CI/CD pipelines",
    ],
    "SSDF Controls": [
      "What are the essential SSDF controls for web application security?",
      "How to implement SSDF controls in a microservices architecture?",
      "Best practices for measuring the effectiveness of SSDF controls",
    ],
  },
}

interface ExampleQuestionsModalProps {
  isOpen: boolean
  onClose: () => void
  setInput: (input: string) => void
}

const ExampleQuestionsModal: React.FC<ExampleQuestionsModalProps> = ({ isOpen, onClose, setInput }) => {
  const { selectedAnalyst } = useAppContext()
  const [selectedTable, setSelectedTable] = useState<string | null>(null)

  if (!selectedAnalyst) return null

  const handleQuestionClick = (question: string) => {
    setInput(question)
    onClose()
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            className="bg-white rounded-lg p-6 w-full max-w-2xl max-h-[80vh] overflow-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <h2 className="text-2xl font-bold mb-4">Example Questions for {selectedAnalyst}</h2>
            <div className="grid grid-cols-3 gap-4 mb-4">
              {Object.keys(exampleQuestions[selectedAnalyst as keyof typeof exampleQuestions]).map((table) => (
                <button
                  key={table}
                  onClick={() => setSelectedTable(table)}
                  className={`p-2 rounded-lg ${
                    selectedTable === table ? "bg-blue-500 text-white" : "bg-gray-200 hover:bg-gray-300"
                  }`}
                >
                  {table}
                </button>
              ))}
            </div>
            {selectedTable && (
              <div>
                <h3 className="text-xl font-semibold mb-2">{selectedTable}</h3>
                <ul>
                  {exampleQuestions[selectedAnalyst as keyof typeof exampleQuestions][
                    selectedTable as keyof (typeof exampleQuestions)[keyof typeof exampleQuestions]
                  ].map((question, index) => (
                    <li
                      key={index}
                      className="mb-2 p-2 bg-gray-100 rounded-lg cursor-pointer hover:bg-gray-200"
                      onDoubleClick={() => handleQuestionClick(question)}
                    >
                      {question}
                    </li>
                  ))}
                </ul>
              </div>
            )}
            <button
              onClick={onClose}
              className="mt-4 bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600 transition-colors duration-200"
            >
              Close
            </button>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

export default ExampleQuestionsModal

