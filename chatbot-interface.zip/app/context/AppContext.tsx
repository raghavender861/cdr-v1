"use client"

import type React from "react"
import { createContext, useState, useContext } from "react"

type AppContextType = {
  currentConversationId: string
  setCurrentConversationId: (id: string) => void
  selectedAnalyst: string | null
  setSelectedAnalyst: (analyst: string | null) => void
  isSidebarOpen: boolean
  setIsSidebarOpen: (isOpen: boolean) => void
  isRightSidebarOpen: boolean
  setIsRightSidebarOpen: (isOpen: boolean) => void
  chatHistory: { id: string; title: string }[]
  setChatHistory: (history: { id: string; title: string }[]) => void
  resetToWelcome: () => void
}

const AppContext = createContext<AppContextType | undefined>(undefined)

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentConversationId, setCurrentConversationId] = useState("")
  const [selectedAnalyst, setSelectedAnalyst] = useState<string | null>(null)
  const [isSidebarOpen, setIsSidebarOpen] = useState(true)
  const [isRightSidebarOpen, setIsRightSidebarOpen] = useState(true)
  const [chatHistory, setChatHistory] = useState<{ id: string; title: string }[]>([])

  const resetToWelcome = () => {
    setCurrentConversationId("")
    setSelectedAnalyst(null)
  }

  return (
    <AppContext.Provider
      value={{
        currentConversationId,
        setCurrentConversationId,
        selectedAnalyst,
        setSelectedAnalyst,
        isSidebarOpen,
        setIsSidebarOpen,
        isRightSidebarOpen,
        setIsRightSidebarOpen,
        chatHistory,
        setChatHistory,
        resetToWelcome,
      }}
    >
      {children}
    </AppContext.Provider>
  )
}

export const useAppContext = () => {
  const context = useContext(AppContext)
  if (context === undefined) {
    throw new Error("useAppContext must be used within an AppProvider")
  }
  return context
}

