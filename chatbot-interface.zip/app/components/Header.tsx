"use client"

import { useAppContext } from "../context/AppContext"

const Header = () => {
  const { resetToWelcome } = useAppContext()

  return (
    <header className="  bg-gradient-to-r from-purple-600 to-indigo-600 text-white p-4 shadow-lg z-50">
      <div className="container mx-auto flex flex-col md:flex-row justify-between items-center">
        <div className="flex items-center mb-2 md:mb-0 cursor-pointer" onClick={resetToWelcome}>
          <h1 className="text-2xl font-bold">CDR Intelligent Hub</h1>
        </div>
        <div className="text-lg">AI Assistant for Cyber</div>
      </div>
    </header>
  )
}

export default Header

