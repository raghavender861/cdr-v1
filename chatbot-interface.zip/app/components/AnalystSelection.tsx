"use client"

import { motion } from "framer-motion"
import { FaBug, FaCloud, FaCode } from "react-icons/fa"
import { useAppContext } from "../context/AppContext"
import { v4 as uuidv4 } from "uuid"

const analysts = [
  {
    title: "Vulnerability Analyst",
    description: "Ask me about OnPrem, AppSec, Cloud Vulnerabilities",
    icon: FaBug,
  },
  {
    title: "Cloud Security Analyst",
    description: "Ask me questions about Cloud Issues, Cloud Resources, Cloud Compliance, Cloud Controls",
    icon: FaCloud,
  },
  {
    title: "SSDF Agent",
    description: "Ask me Questions about SSDF Forms, Tasks, Controls",
    icon: FaCode,
  },
]

const AnalystSelection = () => {
  const { setCurrentConversationId, setSelectedAnalyst } = useAppContext()

  const handleAnalystSelection = (analyst: string) => {
    const newId = `${Date.now()}-${uuidv4()}-${analyst}`
    setCurrentConversationId(newId)
    setSelectedAnalyst(analyst)
  }

  return (
    <div className="container mx-auto p-4 mt-16">
      <h2 className="text-2xl font-bold mb-4 text-center">Please select your desired Analyst</h2>
      <div className="flex flex-col items-center gap-4">
        {analysts.map((analyst, index) => (
          <motion.div
            key={analyst.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white bg-opacity-20 backdrop-filter backdrop-blur-lg rounded-lg shadow-lg overflow-hidden cursor-pointer hover:shadow-xl transition-shadow duration-300 w-full max-w-md"
            onClick={() => handleAnalystSelection(analyst.title)}
          >
            <div className="p-4 bg-gradient-to-r from-blue-500 to-purple-500">
              <h3 className="text-xl font-bold text-white text-center">{analyst.title}</h3>
            </div>
            <div className="p-4 flex items-center">
              <analyst.icon className="text-4xl mr-4 text-blue-500" />
              <p className="text-gray-200">{analyst.description}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  )
}

export default AnalystSelection

