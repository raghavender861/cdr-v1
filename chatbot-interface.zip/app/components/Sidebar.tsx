"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { FaUser, FaSignOutAlt, FaHome, FaPlus } from "react-icons/fa"
import { useAppContext } from "../context/AppContext"
import { v4 as uuidv4 } from "uuid"

const Sidebar = () => {
  const { chatHistory, setCurrentConversationId, selectedAnalyst, setSelectedAnalyst, resetToWelcome } = useAppContext()
  const [isCollapsed, setIsCollapsed] = useState(false)

  const handleNewConversation = () => {
    if (selectedAnalyst) {
      const newId = `${Date.now()}-${uuidv4()}-${selectedAnalyst}`
      setCurrentConversationId(newId)
    }
  }

  return (
    <motion.div
      className={`bg-gray-800 text-white h-full ${
        isCollapsed ? "w-16" : "w-64"
      } transition-all duration-300 ease-in-out overflow-hidden`}
    >
      <div className="p-4">
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="mb-4 text-2xl hover:text-gray-300 transition-colors duration-200"
        >
          {isCollapsed ? "→" : "←"}
        </button>
        <div className="flex items-center mb-4">
          <FaUser className="text-2xl mr-2" />
          {!isCollapsed && <span>Raghavender</span>}
        </div>
        <hr className="border-gray-600 mb-4" />
        <div className="mb-4">
          {!isCollapsed && <h2 className="font-bold mb-2">History</h2>}
          {chatHistory.map((chat) => (
            <button
              key={chat.id}
              onClick={() => setCurrentConversationId(chat.id)}
              className="block w-full text-left mb-2 hover:bg-gray-700 p-2 rounded transition-colors duration-200 truncate"
            >
              {!isCollapsed && chat.title}
            </button>
          ))}
        </div>
      </div>
      <div className="absolute bottom-0 w-full p-4">
        <hr className="border-gray-600 mb-4" />
        {selectedAnalyst && (
          <button
            onClick={handleNewConversation}
            className="flex items-center justify-center w-full mb-2 bg-blue-500 hover:bg-blue-600 p-2 rounded transition-colors duration-200"
          >
            <FaPlus className="text-xl" />
            {!isCollapsed && <span className="ml-2">New Conversation</span>}
          </button>
        )}
        <button
          onClick={resetToWelcome}
          className="flex items-center justify-center w-full mb-2 hover:bg-gray-700 p-2 rounded transition-colors duration-200"
        >
          <FaHome className="text-xl" />
          {!isCollapsed && <span className="ml-2">Home</span>}
        </button>
        <button className="flex items-center justify-center w-full hover:bg-gray-700 p-2 rounded transition-colors duration-200">
          <FaSignOutAlt className="text-xl" />
          {!isCollapsed && <span className="ml-2">Logout</span>}
        </button>
      </div>
    </motion.div>
  )
}

export default Sidebar

